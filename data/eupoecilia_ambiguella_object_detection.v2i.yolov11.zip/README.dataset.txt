# eupoecilia_ambiguella_object_detection > 2025-03-06 8:49pm
https://universe.roboflow.com/pestimages/eupoecilia_ambiguella_object_detection

Provided by a Roboflow user
License: CC BY 4.0

